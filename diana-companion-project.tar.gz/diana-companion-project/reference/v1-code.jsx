import { useState, useEffect, useCallback } from "react";

const CREATURES = [
  { id: "puppy", emoji: "🐶", label: "Puppy" },
  { id: "kitty", emoji: "🐱", label: "Kitty" },
  { id: "angel", emoji: "👼", label: "Angel" },
  { id: "dragon", emoji: "🐲", label: "Dragon" },
  { id: "bunny", emoji: "🐰", label: "Bunny" },
  { id: "fox", emoji: "🦊", label: "Fox" },
];

const WATER_GOAL = 8;

const todayKey = () => {
  const d = new Date();
  return `diana-daily:${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const yesterdayStr = () => {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

// --- Storage helpers ---
async function loadProfile() {
  try {
    const r = await window.storage.get("diana-profile");
    return r ? JSON.parse(r.value) : null;
  } catch { return null; }
}

async function saveProfile(profile) {
  try {
    await window.storage.set("diana-profile", JSON.stringify(profile));
  } catch (e) { console.error("Save profile failed:", e); }
}

async function loadToday() {
  try {
    const r = await window.storage.get(todayKey());
    return r ? JSON.parse(r.value) : null;
  } catch { return null; }
}

async function saveToday(data) {
  try {
    await window.storage.set(todayKey(), JSON.stringify(data));
  } catch (e) { console.error("Save today failed:", e); }
}

// --- Mood logic: based on ENGAGEMENT not values ---
function getCreatureMood(daily) {
  if (!daily) return { level: 0, label: "Waiting for you...", anim: "sleeping" };
  let count = 0;
  if (daily.circles) count++;
  if (daily.water > 0) count++;
  if (daily.energy !== null) count++;
  if (count === 0) return { level: 0, label: "Waiting for you...", anim: "sleeping" };
  if (count === 1) return { level: 1, label: "Happy to see you!", anim: "bounce" };
  if (count === 2) return { level: 2, label: "Feeling good together!", anim: "wiggle" };
  return { level: 3, label: "We're glowing today!", anim: "glow" };
}

// ========================
// STYLES
// ========================
const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap');

  * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }

  :root {
    --bg: #FFF8F3;
    --card: #FFFFFF;
    --primary: #6BA89E;
    --primary-light: #E8F4F1;
    --accent: #E8907E;
    --accent-light: #FDE8E4;
    --text: #3D3535;
    --text-light: #8A7F7F;
    --shadow: 0 2px 16px rgba(109, 89, 75, 0.08);
    --shadow-lg: 0 4px 24px rgba(109, 89, 75, 0.12);
    --green: #6BBF8A;
    --green-bg: #E6F7EC;
    --yellow: #F0C050;
    --yellow-bg: #FFF8E1;
    --red: #E87B7B;
    --red-bg: #FDECEC;
    --blue: #6BA8D6;
    --blue-bg: #E8F1FA;
    --radius: 20px;
  }

  body { 
    font-family: 'Nunito', sans-serif; 
    background: var(--bg); 
    color: var(--text);
    overscroll-behavior: none;
  }

  .app-container {
    max-width: 430px;
    margin: 0 auto;
    min-height: 100dvh;
    display: flex;
    flex-direction: column;
    position: relative;
    padding-bottom: 80px;
  }

  /* Creature animations */
  @keyframes sleeping {
    0%, 100% { transform: scale(1) rotate(-3deg); opacity: 0.7; }
    50% { transform: scale(1.03) rotate(3deg); opacity: 0.85; }
  }
  @keyframes bounce {
    0%, 100% { transform: translateY(0) scale(1); }
    50% { transform: translateY(-8px) scale(1.05); }
  }
  @keyframes wiggle {
    0%, 100% { transform: rotate(0deg) scale(1); }
    25% { transform: rotate(-6deg) scale(1.05); }
    75% { transform: rotate(6deg) scale(1.05); }
  }
  @keyframes glow {
    0%, 100% { transform: scale(1); filter: drop-shadow(0 0 8px rgba(107,168,158,0.3)); }
    50% { transform: scale(1.08); filter: drop-shadow(0 0 20px rgba(107,168,158,0.6)); }
  }
  @keyframes sparkle {
    0%, 100% { opacity: 0; transform: scale(0) rotate(0deg); }
    50% { opacity: 1; transform: scale(1) rotate(180deg); }
  }
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  @keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
  }

  .creature-emoji {
    font-size: 72px;
    display: inline-block;
    line-height: 1;
  }
  .creature-emoji.sleeping { animation: sleeping 3s ease-in-out infinite; }
  .creature-emoji.bounce { animation: bounce 1.2s ease-in-out infinite; }
  .creature-emoji.wiggle { animation: wiggle 0.8s ease-in-out infinite; }
  .creature-emoji.glow { animation: glow 2s ease-in-out infinite; }

  .sparkle-container {
    position: absolute;
    width: 140px; height: 140px;
    pointer-events: none;
  }
  .sparkle {
    position: absolute;
    font-size: 16px;
    animation: sparkle 1.5s ease-in-out infinite;
  }
  .sparkle:nth-child(1) { top: 0; left: 50%; animation-delay: 0s; }
  .sparkle:nth-child(2) { top: 20%; right: 0; animation-delay: 0.3s; }
  .sparkle:nth-child(3) { bottom: 0; left: 30%; animation-delay: 0.6s; }
  .sparkle:nth-child(4) { top: 30%; left: 0; animation-delay: 0.9s; }

  /* Nav bar */
  .nav-bar {
    position: fixed;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 100%;
    max-width: 430px;
    background: var(--card);
    display: flex;
    justify-content: space-around;
    padding: 10px 0 max(10px, env(safe-area-inset-bottom));
    box-shadow: 0 -2px 16px rgba(109,89,75,0.06);
    z-index: 100;
    border-top: 1px solid rgba(0,0,0,0.04);
  }
  .nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
    background: none;
    border: none;
    color: var(--text-light);
    font-family: 'Nunito', sans-serif;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    padding: 4px 12px;
    border-radius: 12px;
    transition: all 0.2s;
  }
  .nav-item.active {
    color: var(--primary);
    background: var(--primary-light);
  }
  .nav-item .nav-icon { font-size: 22px; }
  .nav-item .nav-dot {
    width: 6px; height: 6px;
    border-radius: 50%;
    background: var(--accent);
    margin-top: 2px;
  }

  /* Cards */
  .card {
    background: var(--card);
    border-radius: var(--radius);
    padding: 20px;
    box-shadow: var(--shadow);
    animation: fadeUp 0.4s ease-out;
  }

  /* Buttons */
  .btn {
    border: none;
    border-radius: 16px;
    padding: 16px 24px;
    font-family: 'Nunito', sans-serif;
    font-weight: 700;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.15s;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
  }
  .btn:active { transform: scale(0.97); }
  .btn-primary { background: var(--primary); color: white; }
  .btn-soft { background: var(--primary-light); color: var(--primary); }

  /* Water drops */
  .water-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    padding: 8px 0;
  }
  .water-drop {
    aspect-ratio: 1;
    border-radius: 50%;
    border: 3px solid var(--blue);
    background: transparent;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    cursor: pointer;
    transition: all 0.25s;
  }
  .water-drop.filled {
    background: var(--blue-bg);
    border-color: var(--blue);
    animation: pulse 0.4s ease-out;
  }
  .water-drop:active { transform: scale(0.92); }

  /* Energy scale */
  .energy-options {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .energy-btn {
    border: 2px solid #eee;
    border-radius: 16px;
    padding: 14px 16px;
    background: var(--card);
    font-family: 'Nunito', sans-serif;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 12px;
    transition: all 0.2s;
    text-align: left;
    color: var(--text);
  }
  .energy-btn.selected {
    border-color: var(--primary);
    background: var(--primary-light);
  }
  .energy-btn:active { transform: scale(0.98); }
  .energy-btn .energy-icon { font-size: 24px; flex-shrink: 0; }

  /* Circles buttons */
  .circle-btn {
    border: none;
    border-radius: 20px;
    padding: 20px;
    width: 100%;
    cursor: pointer;
    text-align: left;
    font-family: 'Nunito', sans-serif;
    transition: all 0.2s;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .circle-btn:active { transform: scale(0.97); }
  .circle-btn .circle-label {
    font-size: 18px;
    font-weight: 800;
  }
  .circle-btn .circle-desc {
    font-size: 14px;
    font-weight: 400;
    opacity: 0.8;
  }
  .circle-btn.selected {
    box-shadow: inset 0 0 0 3px rgba(0,0,0,0.15);
  }

  /* Status pills on home */
  .status-row {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
  }
  .status-pill {
    padding: 8px 14px;
    border-radius: 30px;
    font-size: 13px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  /* Onboarding */
  .creature-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
  }
  .creature-option {
    aspect-ratio: 1;
    border-radius: 20px;
    border: 3px solid #eee;
    background: var(--card);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 4px;
    font-size: 40px;
    cursor: pointer;
    transition: all 0.2s;
  }
  .creature-option:active { transform: scale(0.95); }
  .creature-option.selected {
    border-color: var(--primary);
    background: var(--primary-light);
    box-shadow: var(--shadow-lg);
  }
  .creature-option .creature-opt-label {
    font-size: 13px;
    font-weight: 700;
    color: var(--text);
  }

  .name-input {
    width: 100%;
    padding: 14px 16px;
    border: 2px solid #eee;
    border-radius: 16px;
    font-family: 'Nunito', sans-serif;
    font-size: 18px;
    font-weight: 600;
    text-align: center;
    color: var(--text);
    background: var(--card);
    outline: none;
    transition: border-color 0.2s;
  }
  .name-input:focus { border-color: var(--primary); }
  .name-input::placeholder { color: #ccc; }

  .section-title {
    font-size: 14px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--text-light);
    margin-bottom: 10px;
  }

  .streak-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: var(--accent-light);
    color: var(--accent);
    padding: 6px 14px;
    border-radius: 30px;
    font-weight: 800;
    font-size: 14px;
  }

  .header-area {
    text-align: center;
    padding: 24px 20px 0;
  }

  .page-content {
    flex: 1;
    padding: 16px 16px 20px;
    display: flex;
    flex-direction: column;
    gap: 16px;
    overflow-y: auto;
  }

  .done-msg {
    text-align: center;
    padding: 16px;
    border-radius: var(--radius);
    font-weight: 700;
    font-size: 15px;
    animation: fadeUp 0.3s ease-out;
  }

  .reset-btn {
    background: none;
    border: none;
    color: var(--text-light);
    font-family: 'Nunito', sans-serif;
    font-size: 13px;
    cursor: pointer;
    padding: 8px;
    text-decoration: underline;
  }
`;

// ========================
// COMPONENTS
// ========================

function NavBar({ screen, setScreen, daily }) {
  const tabs = [
    { id: "home", icon: "🏠", label: "Home" },
    { id: "circles", icon: "🔵", label: "Circles", done: daily?.circles },
    { id: "water", icon: "💧", label: "Water", done: daily?.water > 0 },
    { id: "energy", icon: "⚡", label: "Energy", done: daily?.energy !== null },
  ];
  return (
    <nav className="nav-bar">
      {tabs.map(t => (
        <button
          key={t.id}
          className={`nav-item ${screen === t.id ? "active" : ""}`}
          onClick={() => setScreen(t.id)}
        >
          <span className="nav-icon">{t.icon}</span>
          <span>{t.label}</span>
          {t.done && t.id !== "home" && !screen.startsWith(t.id) ? null : null}
        </button>
      ))}
    </nav>
  );
}

function Sparkles() {
  return (
    <div className="sparkle-container">
      <span className="sparkle">✨</span>
      <span className="sparkle">⭐</span>
      <span className="sparkle">✨</span>
      <span className="sparkle">💫</span>
    </div>
  );
}

function CreatureDisplay({ creature, mood }) {
  return (
    <div style={{ position: "relative", display: "inline-flex", alignItems: "center", justifyContent: "center" }}>
      {mood.level === 3 && <Sparkles />}
      <span className={`creature-emoji ${mood.anim}`}>{creature.emoji}</span>
    </div>
  );
}

// --- ONBOARDING ---
function Onboarding({ onComplete }) {
  const [step, setStep] = useState(0); // 0=pick, 1=name
  const [selected, setSelected] = useState(null);
  const [name, setName] = useState("");

  return (
    <div className="app-container" style={{ justifyContent: "center" }}>
      <div className="page-content" style={{ justifyContent: "center", gap: 24 }}>
        {step === 0 ? (
          <>
            <div style={{ textAlign: "center" }}>
              <h1 style={{ fontSize: 26, fontWeight: 800, marginBottom: 4 }}>
                Pick Your Buddy
              </h1>
              <p style={{ color: "var(--text-light)", fontSize: 15 }}>
                This little friend will cheer you on every day.
              </p>
            </div>
            <div className="creature-grid">
              {CREATURES.map(c => (
                <button
                  key={c.id}
                  className={`creature-option ${selected?.id === c.id ? "selected" : ""}`}
                  onClick={() => setSelected(c)}
                >
                  <span>{c.emoji}</span>
                  <span className="creature-opt-label">{c.label}</span>
                </button>
              ))}
            </div>
            {selected && (
              <button className="btn btn-primary" onClick={() => setStep(1)}>
                That's the one! →
              </button>
            )}
          </>
        ) : (
          <>
            <div style={{ textAlign: "center" }}>
              <span style={{ fontSize: 64 }}>{selected.emoji}</span>
              <h1 style={{ fontSize: 24, fontWeight: 800, marginTop: 8 }}>
                Name your {selected.label}
              </h1>
              <p style={{ color: "var(--text-light)", fontSize: 15 }}>
                What do you want to call them?
              </p>
            </div>
            <input
              className="name-input"
              placeholder="Type a name..."
              value={name}
              onChange={e => setName(e.target.value)}
              maxLength={20}
              autoFocus
            />
            {name.trim().length > 0 && (
              <button
                className="btn btn-primary"
                onClick={() => onComplete(selected, name.trim())}
              >
                Let's go, {name.trim()}! 🎉
              </button>
            )}
            <button
              className="reset-btn"
              onClick={() => { setStep(0); setSelected(null); }}
            >
              ← pick a different buddy
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// --- HOME SCREEN ---
function HomeScreen({ creature, creatureName, daily, streak }) {
  const mood = getCreatureMood(daily);
  const checkIns = [
    daily?.circles ? "✅ Circles" : "⬜ Circles",
    daily?.water > 0 ? `✅ Water (${daily.water}/${WATER_GOAL})` : "⬜ Water",
    daily?.energy !== null ? "✅ Energy" : "⬜ Energy",
  ];

  return (
    <>
      <div className="header-area">
        {streak > 0 && (
          <div className="streak-badge" style={{ marginBottom: 12 }}>
            🔥 {streak} day{streak > 1 ? "s" : ""} in a row
          </div>
        )}
        <CreatureDisplay creature={creature} mood={mood} />
        <h2 style={{ fontSize: 22, fontWeight: 800, marginTop: 8 }}>
          {creatureName}
        </h2>
        <p style={{ color: "var(--text-light)", fontSize: 15, fontWeight: 600, marginTop: 2 }}>
          {mood.label}
        </p>
      </div>
      <div className="page-content">
        <div className="card">
          <div className="section-title">Today's Check-ins</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {checkIns.map((c, i) => (
              <span key={i} style={{ fontSize: 15, fontWeight: 600 }}>{c}</span>
            ))}
          </div>
        </div>

        {daily?.circles && (
          <div className="card" style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{
              width: 16, height: 16, borderRadius: "50%", flexShrink: 0,
              background: daily.circles === "outer" ? "var(--green)" : daily.circles === "middle" ? "var(--yellow)" : "var(--red)"
            }} />
            <span style={{ fontSize: 15, fontWeight: 600 }}>
              {daily.circles === "outer" && "Outer Circle today — healthy choices 💚"}
              {daily.circles === "middle" && "Middle Circle today — stay aware 💛"}
              {daily.circles === "inner" && "Inner Circle today — you're still here, that matters ❤️"}
            </span>
          </div>
        )}

        {daily?.energy !== null && daily?.energy !== undefined && (
          <div className="card">
            <span style={{ fontSize: 15, fontWeight: 600 }}>
              Energy: {["", "🔋 Crashed", "🪫 Very low", "🔋 Getting by", "⚡ Good energy", "✨ Great energy"][daily.energy]}
            </span>
          </div>
        )}
      </div>
    </>
  );
}

// --- THREE CIRCLES ---
function CirclesScreen({ daily, onSave }) {
  const [selected, setSelected] = useState(daily?.circles || null);
  const saved = daily?.circles;

  const circles = [
    {
      id: "outer",
      label: "Outer Circle 💚",
      desc: "Healthy choices. Things that help me heal.",
      bg: "var(--green-bg)",
      color: "#2d6e45",
    },
    {
      id: "middle",
      label: "Middle Circle 💛",
      desc: "Warning signs. Slipping toward old patterns.",
      bg: "var(--yellow-bg)",
      color: "#7a6520",
    },
    {
      id: "inner",
      label: "Inner Circle ❤️",
      desc: "Acted out. But checking in still matters.",
      bg: "var(--red-bg)",
      color: "#8b3535",
    },
  ];

  return (
    <>
      <div className="header-area">
        <h1 style={{ fontSize: 24, fontWeight: 800 }}>Three Circles</h1>
        <p style={{ color: "var(--text-light)", fontSize: 15 }}>
          Where were you today? Be honest — no judgment here.
        </p>
      </div>
      <div className="page-content">
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {circles.map(c => (
            <button
              key={c.id}
              className={`circle-btn ${selected === c.id ? "selected" : ""}`}
              style={{ background: c.bg, color: c.color }}
              onClick={() => setSelected(c.id)}
            >
              <span className="circle-label">{c.label}</span>
              <span className="circle-desc">{c.desc}</span>
            </button>
          ))}
        </div>

        {selected && !saved && (
          <button className="btn btn-primary" onClick={() => onSave(selected)}>
            Save Check-in
          </button>
        )}

        {saved && (
          <div className="done-msg" style={{ background: "var(--primary-light)", color: "var(--primary)" }}>
            ✅ Checked in for today!
            <br />
            <span style={{ fontSize: 13, fontWeight: 400 }}>
              You can change this if your day shifted.
            </span>
            {selected !== saved && (
              <button
                className="btn btn-soft"
                style={{ marginTop: 12 }}
                onClick={() => onSave(selected)}
              >
                Update to {circles.find(c => c.id === selected)?.label}
              </button>
            )}
          </div>
        )}
      </div>
    </>
  );
}

// --- WATER TRACKER ---
function WaterScreen({ daily, onSave }) {
  const glasses = daily?.water || 0;

  return (
    <>
      <div className="header-area">
        <h1 style={{ fontSize: 24, fontWeight: 800 }}>💧 Water</h1>
        <p style={{ color: "var(--text-light)", fontSize: 15 }}>
          Tap a drop each time you drink a glass.
        </p>
      </div>
      <div className="page-content">
        <div className="card" style={{ textAlign: "center" }}>
          <div style={{ fontSize: 42, fontWeight: 800, color: "var(--blue)" }}>
            {glasses} / {WATER_GOAL}
          </div>
          <div style={{ fontSize: 14, color: "var(--text-light)", fontWeight: 600, marginTop: 2 }}>
            glasses today
          </div>
        </div>

        <div className="card">
          <div className="water-grid">
            {Array.from({ length: WATER_GOAL }).map((_, i) => (
              <button
                key={i}
                className={`water-drop ${i < glasses ? "filled" : ""}`}
                onClick={() => onSave(Math.max(i + 1, glasses === i + 1 ? i : i + 1))}
              >
                {i < glasses ? "💧" : "○"}
              </button>
            ))}
          </div>
        </div>

        <div style={{ display: "flex", gap: 8 }}>
          <button
            className="btn btn-soft"
            style={{ flex: 1 }}
            onClick={() => onSave(Math.max(0, glasses - 1))}
          >
            − Undo one
          </button>
          <button
            className="btn btn-primary"
            style={{ flex: 1 }}
            onClick={() => onSave(Math.min(WATER_GOAL + 4, glasses + 1))}
          >
            + Add one
          </button>
        </div>

        {glasses >= WATER_GOAL && (
          <div className="done-msg" style={{ background: "var(--blue-bg)", color: "var(--blue)" }}>
            🎉 You hit your water goal! Amazing!
          </div>
        )}
      </div>
    </>
  );
}

// --- ENERGY TRACKER ---
function EnergyScreen({ daily, onSave }) {
  const [selected, setSelected] = useState(daily?.energy ?? null);
  const saved = daily?.energy !== null && daily?.energy !== undefined;

  const levels = [
    { value: 1, icon: "😴", label: "Crashed", desc: "No energy. Rest is okay." },
    { value: 2, icon: "🥱", label: "Very low", desc: "Moving slow. Doing what I can." },
    { value: 3, icon: "😐", label: "Getting by", desc: "Not great, not terrible." },
    { value: 4, icon: "😊", label: "Good energy", desc: "Feeling pretty solid today." },
    { value: 5, icon: "🌟", label: "Great energy", desc: "Let's go! Feeling strong." },
  ];

  return (
    <>
      <div className="header-area">
        <h1 style={{ fontSize: 24, fontWeight: 800 }}>⚡ Energy</h1>
        <p style={{ color: "var(--text-light)", fontSize: 15 }}>
          How's your body feeling right now? No wrong answer.
        </p>
      </div>
      <div className="page-content">
        <div className="energy-options">
          {levels.map(l => (
            <button
              key={l.value}
              className={`energy-btn ${selected === l.value ? "selected" : ""}`}
              onClick={() => setSelected(l.value)}
            >
              <span className="energy-icon">{l.icon}</span>
              <div>
                <div style={{ fontWeight: 700 }}>{l.label}</div>
                <div style={{ fontSize: 13, color: "var(--text-light)", fontWeight: 400 }}>
                  {l.desc}
                </div>
              </div>
            </button>
          ))}
        </div>

        {selected !== null && !saved && (
          <button className="btn btn-primary" onClick={() => onSave(selected)}>
            Save Energy Check-in
          </button>
        )}

        {saved && (
          <div className="done-msg" style={{ background: "var(--primary-light)", color: "var(--primary)" }}>
            ✅ Energy logged!
            {selected !== daily.energy && (
              <button
                className="btn btn-soft"
                style={{ marginTop: 12 }}
                onClick={() => onSave(selected)}
              >
                Update to {levels.find(l => l.value === selected)?.label}
              </button>
            )}
          </div>
        )}

        {daily?.energy === 1 && (
          <div className="card" style={{ background: "var(--accent-light)", textAlign: "center" }}>
            <p style={{ fontSize: 15, fontWeight: 600, color: "var(--accent)" }}>
              💕 Crashed days happen. Rest is not giving up — it's taking care of yourself.
            </p>
          </div>
        )}
      </div>
    </>
  );
}

// ========================
// MAIN APP
// ========================
export default function DianaCompanion() {
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);
  const [daily, setDaily] = useState({ circles: null, water: 0, energy: null });
  const [screen, setScreen] = useState("home");

  // Load on mount
  useEffect(() => {
    (async () => {
      try {
        const p = await loadProfile();
        setProfile(p);
        const d = await loadToday();
        if (d) setDaily(d);

        // Update streak on load
        if (p) {
          const today = todayStr();
          const yesterday = yesterdayStr();
          if (p.lastCheckIn === today) {
            // Already checked in today, streak is current
          } else if (p.lastCheckIn === yesterday) {
            // Streak continues, will be updated on first check-in
          } else if (p.lastCheckIn && p.lastCheckIn !== today) {
            // Streak broken if more than 1 day gap
            const last = new Date(p.lastCheckIn);
            const now = new Date(today);
            const diffDays = Math.floor((now - last) / (1000 * 60 * 60 * 24));
            if (diffDays > 1) {
              const updated = { ...p, streak: 0 };
              setProfile(updated);
              await saveProfile(updated);
            }
          }
        }
      } catch (e) {
        console.error("Load error:", e);
      }
      setLoading(false);
    })();
  }, []);

  // Save daily whenever it changes (after initial load)
  const saveDailyData = useCallback(async (newDaily) => {
    setDaily(newDaily);
    await saveToday(newDaily);

    // Update streak
    if (profile) {
      const today = todayStr();
      const yesterday = yesterdayStr();
      let newStreak = profile.streak || 0;

      if (profile.lastCheckIn !== today) {
        if (profile.lastCheckIn === yesterday) {
          newStreak = (profile.streak || 0) + 1;
        } else {
          newStreak = 1;
        }
      }

      const updatedProfile = { ...profile, lastCheckIn: today, streak: newStreak };
      setProfile(updatedProfile);
      await saveProfile(updatedProfile);
    }
  }, [profile]);

  const handleOnboarding = useCallback(async (creature, name) => {
    const p = {
      creatureId: creature.id,
      creatureEmoji: creature.emoji,
      creatureName: name,
      createdAt: new Date().toISOString(),
      streak: 0,
      lastCheckIn: null,
    };
    setProfile(p);
    await saveProfile(p);
  }, []);

  const handleCircles = useCallback((value) => {
    const newDaily = { ...daily, circles: value };
    saveDailyData(newDaily);
  }, [daily, saveDailyData]);

  const handleWater = useCallback((value) => {
    const newDaily = { ...daily, water: value };
    saveDailyData(newDaily);
  }, [daily, saveDailyData]);

  const handleEnergy = useCallback((value) => {
    const newDaily = { ...daily, energy: value };
    saveDailyData(newDaily);
  }, [daily, saveDailyData]);

  if (loading) {
    return (
      <div className="app-container" style={{ justifyContent: "center", alignItems: "center" }}>
        <style>{styles}</style>
        <span style={{ fontSize: 48, animation: "bounce 1s ease-in-out infinite" }}>💫</span>
      </div>
    );
  }

  if (!profile) {
    return (
      <>
        <style>{styles}</style>
        <Onboarding onComplete={handleOnboarding} />
      </>
    );
  }

  const creature = { id: profile.creatureId, emoji: profile.creatureEmoji };

  return (
    <>
      <style>{styles}</style>
      <div className="app-container">
        {screen === "home" && (
          <HomeScreen
            creature={creature}
            creatureName={profile.creatureName}
            daily={daily}
            streak={profile.streak || 0}
          />
        )}
        {screen === "circles" && (
          <CirclesScreen daily={daily} onSave={handleCircles} />
        )}
        {screen === "water" && (
          <WaterScreen daily={daily} onSave={handleWater} />
        )}
        {screen === "energy" && (
          <EnergyScreen daily={daily} onSave={handleEnergy} />
        )}
        <NavBar screen={screen} setScreen={setScreen} daily={daily} />
      </div>
    </>
  );
}
