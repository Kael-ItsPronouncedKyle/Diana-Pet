# Diana's Companion App — V2 Project Files

## How to Use This in Claude Code

### Step 1: Create a new Claude Code project folder on your machine

```
mkdir diana-companion-v2
cd diana-companion-v2
```

### Step 2: Copy all these files into that folder, keeping the structure

```
diana-companion-v2/
├── CLAUDE.md              ← Claude Code reads this automatically
├── PROMPT.md              ← Full build spec (the big prompt)
├── README.md              ← You're reading this
├── data/
│   ├── dbt-skills.json    ← 22 DBT skills, pre-written at Diana's reading level
│   ├── word-of-the-day.json ← 35 vocabulary words with definitions and sentences
│   └── puppy-phases.json  ← All 3 training phases, both dogs, from the real guide
└── reference/
    ├── diana-profile.md   ← Who Diana is (clinical, personal, design implications)
    ├── v1-code.jsx        ← Working v1 app (design reference, not to be patched)
    ├── training-guide-notes.md  ← Key details from the dog training PDF
    └── training-guide.pdf ← The full Apollo & Artemis training guide
```

### Step 3: Open Claude Code in that folder

```
claude
```

### Step 4: Give it the build command

Say this (or something like it):

```
Read CLAUDE.md and PROMPT.md, then read all files in data/ and reference/. 
Build the complete app as described in PROMPT.md. 
Output a single file: diana-companion-v2.jsx
Embed the data from the JSON files directly into the component.
```

### If it hits context limits

The app is large. If Claude Code can't build it in one pass, say:

```
Build the app in stages. Start with the must-have sections listed in CLAUDE.md.
Save your progress after each stage. I'll tell you when to continue.
```

The CLAUDE.md file has a priority order for which sections to build first.

### What you'll get back

A single `diana-companion-v2.jsx` file that you can:
- Drop into Claude.ai as an artifact to test
- Deploy as a standalone React app
- Share with Diana as a webapp on her iPhone

## File Descriptions

| File | Purpose |
|------|---------|
| `CLAUDE.md` | Project instructions Claude Code reads automatically on startup. Contains build rules, priority order, tech constraints, color palette, storage API docs. |
| `PROMPT.md` | The complete 17-section build specification. Every screen, every interaction, every piece of copy. This is the bible. |
| `data/dbt-skills.json` | 22 DBT skills pre-written at 3rd grade reading level with category, description, and concrete practice instructions. Embed directly in the component. |
| `data/word-of-the-day.json` | 35 vocabulary words relevant to Diana's life — recovery, health, dogs, self-advocacy. Each has a definition and a sentence using Diana's name. |
| `data/puppy-phases.json` | Structured training data for Apollo and Artemis across all 3 phases. Includes per-dog skills, rotating tips, trainer options, and phase advancement rules. |
| `reference/diana-profile.md` | Comprehensive profile of who Diana is — clinical picture, cognitive profile, language requirements, emotional safety rules, and non-negotiables. |
| `reference/v1-code.jsx` | The working v1 app. Establishes the design language, animation approach, color palette, and storage patterns. Build fresh but carry forward the feel. |
| `reference/training-guide-notes.md` | Key details extracted from the full training guide — breed info, critical rules, Apollo's reactivity plan, Artemis's PSD pathway, equipment list, Luis's role. |
| `reference/training-guide.pdf` | The full 20-page Apollo & Artemis training guide. Available for deep reference but the notes file covers what the app needs. |

## Notes

- The JSON data files should be **embedded directly into the JSX component** as JavaScript objects/arrays — not loaded as external files. This keeps it as a single-file artifact.
- The training guide PDF is included for reference but Claude Code should primarily use `training-guide-notes.md` and `puppy-phases.json` which have the structured data it needs.
- The v1 code is reference only. Do not patch it. Build fresh.
